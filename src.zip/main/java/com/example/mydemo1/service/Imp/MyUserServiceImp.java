package com.example.mydemo1.service.Imp;

import com.example.mydemo1.dao.MyUsrDao;
import com.example.mydemo1.entity.Myuser;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;

@Service
public class MyUserServiceImp implements com.example.mydemo1.service.MyUserService {

    @Resource
    MyUsrDao myUsrDao;


    @Override
    public Myuser get(int id) {
        Myuser myuser= myUsrDao.getId(id);
        return myuser;
    }

    @Override
    public List<Myuser> getAll() {
        return myUsrDao.getAll();
    }

    @Override
    public List<Myuser> getConditionAll(int user_id, String user_software, String pageNum, String pageSize) {
        return null;
    }

    @Override
    public int update(Myuser myuser) {
        return myUsrDao.update(myuser);
    }

    @Override
    public int deletes(int id) {
        return myUsrDao.delete(id);
    }
    @Override
    public int save(Myuser myuser) {
        return myUsrDao.save(myuser);
    }
}
