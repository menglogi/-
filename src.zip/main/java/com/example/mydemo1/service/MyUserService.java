package com.example.mydemo1.service;

import com.example.mydemo1.entity.Myuser;

import java.util.List;

public interface MyUserService {
    //单条查询
    public Myuser get(int id);
    //查询全部
    public List<Myuser> getAll();
    //分页条件查询
    public List<Myuser> getConditionAll(int user_id,String user_software,String pageNum,String pageSize);
    //单条数据修改
    public  int update(Myuser myuser);
    //单条记录删除
    public  int deletes (int id);
    //新增
    public  int  save(Myuser myuser);


}
