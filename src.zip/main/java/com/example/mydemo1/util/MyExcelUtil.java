package com.example.mydemo1.util;


import com.example.mydemo1.entity.CheckAndAccept;
import org.apache.poi.POIXMLDocumentPart;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.PictureData;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.*;
import org.openxmlformats.schemas.drawingml.x2006.spreadsheetDrawing.CTMarker;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class MyExcelUtil {

    /**
     * 判断文件是否存在
     *
     * @param fileName
     * @return
     */
    public static boolean fileExist(String fileName) {
        boolean flag = false;
        File file = new File(fileName);
        flag = file.exists();
        return flag;
    }

//    /**
//     * 新文件写入数据
//     *
//     * @return
//     */
//    public static List<User> writeNewFile() {
//        List<User> userList = new ArrayList<>();
//        User user;
//        for (int i = 0; i < 10; i++) {
//            user = new User();
//            user.setName("u" + i);
//            user.setAge(i);
//            user.setSex("男");
//            userList.add(user);
//        }
//        return userList;
//    }

    /**
     * 从excel中读取数据
     *
     * @param xls         true xls文件，false xlsx文件
     * @param inputStream 文件输入流
     * @return 数据封装到对象
     */
    public static List<CheckAndAccept> getDataFromExcel(boolean xls, InputStream inputStream) {
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
        Workbook workbook = null;
        List<CheckAndAccept> userList = new ArrayList<>();
        try {
            if (xls) {
                workbook = new HSSFWorkbook(inputStream);
            } else {
                workbook = new XSSFWorkbook(inputStream);
            }

            // 得到一个工作表
            Sheet sheet = workbook.getSheetAt(0);
            // 得到表头
            Row rowHead = sheet.getRow(0);
            // 判断表头是否正确
            if (rowHead.getPhysicalNumberOfCells() < 1) {
                throw new Exception("表头错误");
            }

            // 获取照片
            Map<String, PictureData> pictures;
            if (xls) {
                pictures = getPictures((HSSFSheet) sheet);
            } else {
                pictures = getPictures((XSSFSheet) sheet);
            }

            // 获取数据
            for (int i = 2; i <= sheet.getLastRowNum(); i++) {
                // 获取第i行
                Row row = sheet.getRow(i);
                // 获取第i行各个列的数据
                Integer id = (int) row.getCell(0).getNumericCellValue();
                String username = row.getCell(1).getStringCellValue();
                Integer age = (int) row.getCell(2).getNumericCellValue();
                String sex = row.getCell(3).getStringCellValue();
                String savePath = savePicture(id, pictures.get(i + "-4"));
                String date;
                // 判断该单元格的数据类型
                switch (row.getCell(5).getCellTypeEnum()) {
                    case STRING: // 字符串类型
                        date = row.getCell(5).getStringCellValue();
                        break;
                    case NUMERIC: // 日期类型
                        date = sf.format(row.getCell(5).getDateCellValue());
                        break;
                    default:
                        date = "";
                        break;
                }
//                userList.add(new CheckAndAccept(id, username, age, sex, savePath, date));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return userList;
    }

    /**
     * xls获取照片
     */
    private static Map<String, PictureData> getPictures(HSSFSheet sheet) {
        Map<String, PictureData> map = new HashMap<>();
        List<HSSFShape> list = sheet.getDrawingPatriarch().getChildren();
        for (HSSFShape shape : list) {
            if (shape instanceof HSSFPicture) {
                HSSFPicture picture = (HSSFPicture) shape;
                HSSFClientAnchor clientAnchor = picture.getClientAnchor();
                HSSFPictureData pictureData = picture.getPictureData();
                String key = clientAnchor.getRow1() + "-" + clientAnchor.getCol1();
                map.put(key, pictureData);
            }
        }
        return map;
    }

    /**
     * xlsx获取照片
     */
    private static Map<String, PictureData> getPictures(XSSFSheet sheet) {
        Map<String, PictureData> map = new HashMap<>();
        List<POIXMLDocumentPart> list = sheet.getRelations();
        for (POIXMLDocumentPart part : list) {
            if (part instanceof XSSFDrawing) {
                XSSFDrawing drawing = (XSSFDrawing) part;
                List<XSSFShape> shapes = drawing.getShapes();
                for (XSSFShape shape : shapes) {
                    XSSFPicture picture = (XSSFPicture) shape;
                    XSSFClientAnchor anchor = picture.getPreferredSize();
                    CTMarker marker = anchor.getFrom();
                    String key = marker.getRow() + "-" + marker.getCol();
                    map.put(key, picture.getPictureData());
                }
            }
        }
        return map;
    }

    /**
     * 照片保存在本地
     */
    private static String savePicture(int id, PictureData picData) throws IOException {
        if (picData != null) {
            byte[] data = picData.getData();
            String fileName = id + "-" + "照片";
            String filePath = "F:\\YaSuo";
            FileOutputStream out = new FileOutputStream(filePath + fileName + ".png");
            out.write(data);
            out.close();
            return filePath + fileName + ".png";
        }
        return "";
    }
}
