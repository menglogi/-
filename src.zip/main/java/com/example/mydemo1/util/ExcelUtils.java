package com.example.mydemo1.util;

import com.example.mydemo1.entity.CheckAndAccept;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.POIXMLDocumentPart;
import org.apache.poi.hssf.usermodel.*;
//import org.apache.poi.ooxml.POIXMLDocumentPart;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.util.Units;
import org.apache.poi.xssf.usermodel.*;
import org.openxmlformats.schemas.drawingml.x2006.spreadsheetDrawing.CTMarker;
import org.springframework.util.StringUtils;

import javax.imageio.ImageIO;
import javax.xml.bind.DatatypeConverter;
import java.awt.image.BufferedImage;
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExcelUtils {
    public static void main(String[] args) throws IOException {
        Workbook workbook  = null;
        workbook= new XSSFWorkbook("E:\\洛阳金鹭\\6月份\\2021BKMCGL0037验收表.xlsx");//Excel 2007
        List<Object> list=importExcel(workbook, CheckAndAccept.class,"E:\\洛阳金鹭\\6月份\\2021BKMCGL0016验收表.xlsx");
    }

    /**
     * 从Workbook导入Excel文件，并封装成对象
     *
     * @param workbook
     * @param sheetClass
     * @param filePath
     * @return List<Object>
     */
    private static List<Object> importExcel(Workbook workbook, Class<?> sheetClass, String filePath) throws IOException {
        List<Object> sheetDataList = importSheet(workbook, sheetClass, filePath);
        return sheetDataList;
    }
    private static List<Object> importExcel2(Workbook workbook, Class<?> sheetClass, String filePath) throws IOException {
        List<Object> sheetDataList = importSheet2(workbook, sheetClass, filePath);
        return sheetDataList;
    }

    private static List<Object> importSheet2(Workbook workbook, Class<?> sheetClass, String filePath) throws IOException {
        String fileFormat = filePath.substring(filePath.lastIndexOf("."));
        List<Object> dataList = new ArrayList<>();
//        ExcelSheetDto dto = new ExcelSheetDto();
        Sheet sheet = workbook.getSheetAt(0);
        List<CellRangeAddress>  cellRangeAddresses= sheet.getMergedRegions(); //待用
        List<Cell> cells = new ArrayList<>();
        for(int i = 0;i<20;i++){
            XSSFRow row = (XSSFRow) sheet.getRow(i);
            if(row!=null){
                for(int j = 0;j<row.getPhysicalNumberOfCells();j++) {
                    Cell cell = row.getCell(j);
                    if(cell!=null){
                        cell.setCellType(CellType.STRING);
                        if(!StringUtils.isEmpty(cell.getStringCellValue())){
                            cells.add(cell);
                        }
                    }
                }
            }
        }
        Map<String, List<PictureData>> map1 = new HashMap<String, List<PictureData>>();
        if (".xlsx".equals(fileFormat)) {
            map1 = getPictures2((XSSFSheet) workbook.getSheetAt(0));
        } else if (".xls".equals(fileFormat)) {
            map1 = getPictures1((HSSFSheet) workbook.getSheetAt(0));
        }
        Map<String, List<PictureData>> finalMap = map1;
        cells.forEach(cell-> {
            String fileds = cell.getStringCellValue();
            int ColIndex = cell.getColumnIndex();
            int RowIndex = cell.getRowIndex();
            if ("BKM编号".equals(fileds) || "BKM编号：".equals(fileds)) {
//                dto.setCode(sheet.getRow(RowIndex).getCell(ColIndex + 1).getStringCellValue());
//                if (StringUtils.isEmpty(dto.getCode())) {
//                    dto.setCode(sheet.getRow(RowIndex).getCell(ColIndex + 2).getStringCellValue());
//                }
            }
            if ("BKM名称".equals(fileds) || "BKM项目名".equals(fileds)) {
//                dto.setName(sheet.getRow(RowIndex).getCell(ColIndex + 2).getStringCellValue());
            }
            if ("申报公司".equals(fileds)) {
//                dto.setApplcompanyid(sheet.getRow(RowIndex).getCell(ColIndex + 2).getStringCellValue());
            }
            if ("申报事业部".equals(fileds) || "位置".equals(fileds)) {
//                dto.setAppldivisionid(sheet.getRow(RowIndex).getCell(ColIndex + 2).getStringCellValue());
//                if (StringUtils.isEmpty(dto.getAppldivisionid())) {
//                    dto.setAppldivisionid(sheet.getRow(RowIndex).getCell(ColIndex + 1).getStringCellValue());
//                }
            }
            if ("申报人/岗位".equals(fileds) || "申报人".equals(fileds)) {
//                dto.setApplusername(sheet.getRow(RowIndex).getCell(ColIndex + 2).getStringCellValue());
//                if (StringUtils.isEmpty(dto.getApplusername())) {
//                    dto.setApplusername(sheet.getRow(RowIndex).getCell(ColIndex + 1).getStringCellValue());
//                }
            }
            if ("实施团队".equals(fileds)) {
//                dto.setImplementteam(sheet.getRow(RowIndex).getCell(ColIndex + 2).getStringCellValue());
            }
            if ("改善时长".equals(fileds)) {
                String value = sheet.getRow(RowIndex).getCell(ColIndex + 1).getStringCellValue();
                if (StringUtils.isEmpty(value)) {
                    value = sheet.getRow(RowIndex).getCell(ColIndex + 2).getStringCellValue();
                }
                String before = null;
                String after = null;
                if (value.contains("-")) {
                    before = value.substring(0, value.indexOf("-"));
                    after = value.substring(value.indexOf("-") + 1);
                } else if (value.contains("~")){
                    before = value.substring(0, value.indexOf("~"));
                    after = value.substring(value.indexOf("~") + 1);
                } else if (value.contains("——")){
                    before = value.substring(0, value.indexOf("——"));
                    after = value.substring(value.indexOf("——") + 1);
                }
                if (before!=null) {
                    if (before.contains("日")) {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日");
//                            dto.setImprovebeforedate(sdf.parse(before));
                    } else if (before.contains("年")) {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月");
//                            dto.setImprovebeforedate(sdf.parse(before));
                    } else if (before.contains(".")) {
                        SimpleDateFormat sdf  = new SimpleDateFormat("yyyy.MM.dd");
                        if (before.length()<=7) {
                            sdf = new SimpleDateFormat("yyyy.MM");
                        }
//                            dto.setImprovebeforedate(sdf.parse(before));
                    } else if (before.contains("/")) {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
                        if (before.length()<=7) {
                            sdf = new SimpleDateFormat("yyyy/MM");
                        }
//                            dto.setImprovebeforedate(sdf.parse(before));
                    }
                }
                if (after!=null) {
                    if (after.contains("至今")) {
//                            dto.setImproveafterdate(new Date());
                    } else if (after.contains("日")) {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日");
//                            dto.setImproveafterdate(sdf.parse(after));
                    } else if (after.contains("年")) {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月");
//                            dto.setImproveafterdate(sdf.parse(after));
                    } else if (after.contains(".")) {
                        SimpleDateFormat sdf  = new SimpleDateFormat("yyyy.MM.dd");
                        if (after.length()<=7) {
                            sdf = new SimpleDateFormat("yyyy.MM");
                        }
//                            dto.setImproveafterdate(sdf.parse(after));
                    } else if (after.contains("/")) {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
                        if (after.length()<=7) {
                            sdf = new SimpleDateFormat("yyyy/MM");
                        }
//                            dto.setImproveafterdate(sdf.parse(after));
                    }
                }
            }
            if("改善前：".equals(fileds)||"改善前".equals(fileds)||fileds.matches("改善前[\\S\\s]{3,}")){
                String imgurl1 = "";
                for (String key : finalMap.keySet()) {
                    if(Integer.parseInt(key.substring(key.indexOf("-")+1))<4){
                        List<PictureData> pic1List = finalMap.get(key);
                        try {
                            imgurl1 += getImgUrl(pic1List);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                            continue;
                        }
                    }
                }
                if(fileds.matches("改善前[\\S\\s]{3,}")){
//                    dto.setImprovebefore(imgurl1+"<p>"+sheet.getRow(RowIndex).getCell(ColIndex).getStringCellValue()+"</p>");
                }else{
//                    dto.setImprovebefore(imgurl1+"<p>"+sheet.getRow(RowIndex+1).getCell(ColIndex).getStringCellValue()+"</p>");
                }
            }
            if("改善后：".equals(fileds)||"改善后".equals(fileds)||fileds.matches("改善后[\\S\\s]{3,}")){
                String imgurl1 = "";
                for (String key : finalMap.keySet()) {
                    if(Integer.parseInt(key.substring(key.indexOf("-")+1))>=4){
                        List<PictureData> pic1List = finalMap.get(key);
                        try {
                            imgurl1 += getImgUrl(pic1List);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                            continue;
                        }
                    }
                }
                if(fileds.matches("改善后[\\S\\s]{3,}")){
//                    dto.setImproveafter(imgurl1+"<p>"+sheet.getRow(RowIndex).getCell(ColIndex).getStringCellValue()+"</p>");
                }else{
//                    dto.setImproveafter(imgurl1+"<p>"+sheet.getRow(RowIndex+1).getCell(ColIndex).getStringCellValue()+"</p>");
                }
            }
            if("适用场景".equals(fileds)){
//                dto.setApplicablescenario(sheet.getRow(RowIndex).getCell(ColIndex+2).getStringCellValue());
            }
            if("建议推广单位".equals(fileds)||fileds.matches("建议推广单位[\\S\\s]{3,}")){
//                dto.setPromotionunit(sheet.getRow(RowIndex).getCell(ColIndex+2).getStringCellValue());
            }
            if("BKM方法说明".equals(fileds)||"实施方法说明".equals(fileds)||"方法说明".equals(fileds)){
//                dto.setInstructions(sheet.getRow(RowIndex).getCell(ColIndex+2).getStringCellValue());
            }
            if("优缺点".equals(fileds)||"优缺点比较".equals(fileds)){
//                dto.setAdvanddisad(sheet.getRow(RowIndex).getCell(ColIndex+2).getStringCellValue());
            }
            if("资源投入".equals(fileds)){
//                dto.setInvestment(sheet.getRow(RowIndex).getCell(ColIndex+2).getStringCellValue());
            }
            if("直接或间接经济效益".equals(fileds)||fileds.matches("直接或间接[\\S\\s]{3,}")){
//                dto.setEconbenefit(sheet.getRow(RowIndex).getCell(ColIndex+2).getStringCellValue());
//                if (StringUtils.isEmpty(dto.getEconbenefit())) {
//                    dto.setEconbenefit(sheet.getRow(RowIndex).getCell(ColIndex+1).getStringCellValue());
//                }
            }
            if("管理效益".equals(fileds)){
//                dto.setMgtbenefit(sheet.getRow(RowIndex).getCell(ColIndex+2).getStringCellValue());
//                if (StringUtils.isEmpty(dto.getMgtbenefit())) {
//                    dto.setMgtbenefit(sheet.getRow(RowIndex).getCell(ColIndex+1).getStringCellValue());
//                }
            }
        });
//        dataList.add(dto);
        return dataList;
    }


    private static List<Object> importSheet(Workbook workbook, Class<?> sheetClass, String filePath) throws IOException {
        // sheet
        String fileFormat = filePath.substring(filePath.lastIndexOf("."));
        List<Object> dataList = new ArrayList<>();
//        ExcelSheetDto dto = new ExcelSheetDto();
        Sheet sheet = workbook.getSheetAt(0);
        if (sheet == null) {
            return null;
        }
        String version = sheet.getRow(1).getCell(6).getStringCellValue();
        if (version == "") {
            version = sheet.getRow(1).getCell(7).getStringCellValue();
        }
        if (version.indexOf("1") != -1) { //V1.0
//            dto.setCode(sheet.getRow(1).getCell(2).getStringCellValue());
//            dto.setApplcompanyid(sheet.getRow(3).getCell(2).getStringCellValue());
//            dto.setApplusername(sheet.getRow(3).getCell(6).getStringCellValue());
//            dto.setName(sheet.getRow(4).getCell(2).getStringCellValue());
//            dto.setImplementteam(sheet.getRow(5).getCell(2).getStringCellValue());
            Map<String, List<PictureData>> map = new HashMap<String, List<PictureData>>();
            if (".xlsx".equals(fileFormat)) {
                map = getPictures2((XSSFSheet) workbook.getSheetAt(0));
            } else if (".xls".equals(fileFormat)) {
                map = getPictures1((HSSFSheet) workbook.getSheetAt(0));
            }
            String imgurl1 = null;
            List<PictureData> pic1List = map.get("8-0");
            imgurl1 = getImgUrl(pic1List);
            List<PictureData> pic2List = map.get("8-1");
            imgurl1 += getImgUrl(pic2List);
            List<PictureData> pic3List = map.get("8-2");
            imgurl1 += getImgUrl(pic3List);
            List<PictureData> pic4List = map.get("8-3");
            imgurl1 += getImgUrl(pic4List);
//            dto.setImprovebefore(imgurl1+"<p>"+sheet.getRow(8).getCell(0).getStringCellValue()+"</p>");
            String imgurl2 = null;
            List<PictureData> pic5List = map.get("8-4");
            imgurl2 = getImgUrl(pic5List);
            List<PictureData> pic6List = map.get("8-5");
            imgurl2 += getImgUrl(pic6List);
            List<PictureData> pic7List = map.get("8-6");
            imgurl2 += getImgUrl(pic7List);
            List<PictureData> pic8List = map.get("8-7");
            imgurl2 += getImgUrl(pic8List);
//            dto.setImproveafter(imgurl2+"<p>"+sheet.getRow(8).getCell(4).getStringCellValue()+"</p>");
//            dto.setApplicablescenario(sheet.getRow(10).getCell(2).getStringCellValue());
//            dto.setInstructions(sheet.getRow(11).getCell(2).getStringCellValue());
//            dto.setAdvanddisad(sheet.getRow(12).getCell(2).getStringCellValue());
//            dto.setInvestment(sheet.getRow(13).getCell(2).getStringCellValue());
//
//            dto.setPromotionunit(sheet.getRow(15).getCell(2).getStringCellValue());
//            dto.setRemark("V1.0"+ ";" +filePath.substring(filePath.lastIndexOf("\\")+1));
        } else {
//            dto.setCode(sheet.getRow(2).getCell(7).getStringCellValue());
//            dto.setName(sheet.getRow(3).getCell(2).getStringCellValue());
//            dto.setApplcompanyid(sheet.getRow(3).getCell(6).getStringCellValue());
//            dto.setAppldivisionid(sheet.getRow(4).getCell(2).getStringCellValue());
//            dto.setApplusername(sheet.getRow(4).getCell(6).getStringCellValue());
//            dto.setImplementteam(sheet.getRow(5).getCell(2).getStringCellValue());
            Map<String, List<PictureData>> map = new HashMap<String, List<PictureData>>();
            if (".xlsx".equals(fileFormat)) {
                map = getPictures2((XSSFSheet) workbook.getSheetAt(0));
            } else if (".xls".equals(fileFormat)) {
                map = getPictures1((HSSFSheet) workbook.getSheetAt(0));
            }
            String imgurl1 = null;
            List<PictureData> pic1List = map.get("8-0");
            imgurl1 = getImgUrl(pic1List);
            List<PictureData> pic2List = map.get("8-1");
            imgurl1 += getImgUrl(pic2List);
            List<PictureData> pic3List = map.get("8-2");
            imgurl1 += getImgUrl(pic3List);
            List<PictureData> pic4List = map.get("8-3");
            imgurl1 += getImgUrl(pic4List);
//            dto.setImprovebefore(imgurl1+"<p>"+sheet.getRow(8).getCell(0).getStringCellValue()+"</p>");
            String imgurl2 = null;
            List<PictureData> pic5List = map.get("8-4");
            imgurl2 = getImgUrl(pic5List);
            List<PictureData> pic6List = map.get("8-5");
            imgurl2 += getImgUrl(pic6List);
            List<PictureData> pic7List = map.get("8-6");
            imgurl2 += getImgUrl(pic7List);
            List<PictureData> pic8List = map.get("8-7");
            imgurl2 += getImgUrl(pic8List);
//            dto.setImproveafter(imgurl2+"<p>"+sheet.getRow(8).getCell(4).getStringCellValue()+"</p>");
//
//            dto.setApplicablescenario(sheet.getRow(10).getCell(2).getStringCellValue());
//            dto.setPromotionunit(sheet.getRow(11).getCell(2).getStringCellValue());
//            dto.setInstructions(sheet.getRow(12).getCell(2).getStringCellValue());
//            dto.setAdvanddisad(sheet.getRow(13).getCell(2).getStringCellValue());
//            dto.setInvestment(sheet.getRow(14).getCell(2).getStringCellValue());
//            dto.setEconbenefit(sheet.getRow(15).getCell(2).getStringCellValue());
//            dto.setMgtbenefit(sheet.getRow(16).getCell(2).getStringCellValue());

//            dto.setRemark("V2.0"+ ";" +filePath.substring(filePath.lastIndexOf("\\")+1));
        }
//        dataList.add(dto);

        return dataList;
    }

    /**
     * 导入Excel文件，并封装成对象
     *
     * @param excelFile
     * @param sheetClass
     * @param filePath
     * @return List<Object>
     */
    public static List<Object> importExcel(File excelFile, Class<?> sheetClass, String filePath) {
        List<Object> dataList=null;
        try {
            Workbook workbook = WorkbookFactory.create(excelFile);
            dataList = importExcel(workbook, sheetClass, filePath);
            return dataList;
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (EncryptedDocumentException e) {
            throw new RuntimeException(e);
        } catch (InvalidFormatException e) {
            e.printStackTrace();
        }
        return dataList;
    }

    public static List<Object> importExcel2(File excelFile, Class<?> sheetClass, String filePath) {
        List<Object> dataList=null;
        try {
            Workbook workbook = WorkbookFactory.create(excelFile);
            dataList = importExcel2(workbook, sheetClass, filePath);
            return dataList;
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (EncryptedDocumentException e) {
            throw new RuntimeException(e);
        } catch (InvalidFormatException e) {
            e.printStackTrace();
        }
        return dataList;
    }

    /**
     * 从文件路径导入Excel文件，并封装成对象
     *
     * @param filePath
     * @param sheetClass
     * @return List<Object>
     */
    public static List<Object> importExcel(String filePath, Class<?> sheetClass) {
        File excelFile = new File(filePath);
        List<Object> dataList = importExcel(excelFile, sheetClass, filePath);
        return dataList;
    }
    public static List<Object> importExcel2(String filePath, Class<?> sheetClass) {
        File excelFile = new File(filePath);
        List<Object> dataList = importExcel2(excelFile, sheetClass, filePath);
        return dataList;
    }



    public static String getImgUrl(List<PictureData> picList) throws FileNotFoundException {
        String imgurl = "";
        if (picList!=null && picList.size()>0) {
            for(PictureData pic:picList) {
                imgurl += "<p><img src=\""+upload(pic)+"\"/></p>";
            }
        }
        return imgurl;
    }

    // 读取图片 XLX
    public static Map<String, List<PictureData>> getPictures1(HSSFSheet sheet) throws IOException {
        Map<String, List<PictureData>> map = new HashMap<String, List<PictureData>>();
        List<HSSFShape> list = sheet.getDrawingPatriarch().getChildren();
        for (HSSFShape shape : list) {
            if (shape instanceof HSSFPicture) {
                HSSFPicture picture = (HSSFPicture) shape;
                HSSFClientAnchor cAnchor = (HSSFClientAnchor) picture.getAnchor();
                PictureData pdata = picture.getPictureData();
                String key = cAnchor.getRow1() + "-" + cAnchor.getCol1(); // 行号-列号
                if (map.get(key) == null) {
                    List<PictureData> pictureDataList = new ArrayList<>();
                    pictureDataList.add(pdata);
                    map.put(key, pictureDataList);
                } else {
                    List<PictureData> pictureDataList = map.get(key);
                    pictureDataList.add(pdata);
                    map.put(key,pictureDataList);
                }
            }
        }
        return map;
    }

    //读取图片 XLSX
    public static Map<String, List<PictureData>> getPictures2(XSSFSheet sheet) throws IOException {
        Map<String,  List<PictureData>> map = new HashMap<String, List<PictureData>>();
        List<POIXMLDocumentPart> list = sheet.getRelations();
        for (POIXMLDocumentPart part : list) {
            if (part instanceof XSSFDrawing) {
                XSSFDrawing drawing = (XSSFDrawing) part;
                List<XSSFShape> shapes = drawing.getShapes();
                for (XSSFShape shape : shapes) {
                   try {
                       XSSFPicture picture = (XSSFPicture) shape;
                       XSSFClientAnchor anchor = picture.getClientAnchor();
                       CTMarker marker = anchor.getFrom();
                       String key = marker.getRow() + "-" + marker.getCol();
                       if (map.get(key) == null) {
                           List<PictureData> pictureDataList = new ArrayList<>();
                           pictureDataList.add(picture.getPictureData());
                           map.put(key, pictureDataList);
                       } else {
                           List<PictureData> pictureDataList = map.get(key);
                           pictureDataList.add(picture.getPictureData());
                           map.put(key,pictureDataList);
                       }
                   } catch (Exception e) {
                       e.getMessage();
                   }
                }
            }
        }
        return map;
    }

    public static String upload(PictureData pic) throws FileNotFoundException {
        Date date = new Date();
        String dateFilename = new SimpleDateFormat("yyyy_MM_dd").format(date);
        String fileSavePath = "D:/WebSiteFile/BKM/image" + "/" + dateFilename;
        File f = new File(fileSavePath);
        if (!f.exists()) {
            f.mkdir();
        }
        String ext = pic.suggestFileExtension();//图片格式
        String fileName = UUID.randomUUID().toString().replace("-", "")+"."+ext;
        String imgRealPath = fileSavePath + "/" + fileName;
        byte[] data = pic.getData();
        FileOutputStream out = new FileOutputStream(imgRealPath);
        try{
            out.write(data);
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return imgRealPath.substring(imgRealPath.indexOf(":")+1);
    }


//     /**
//     *导出Excel
//     * @param dto
//     * @param excelFile
//     * @throws IOException
//      * @return
//     */
//    public static String exportExcel(ExcelSheetDto dto, File excelFile) throws IOException {
//
//        //通过流的方式避免修改模板文件
//        InputStream input=new FileInputStream(excelFile);
//        Workbook workbook = new XSSFWorkbook(input);
//
//        XSSFSheet sheet = (XSSFSheet) workbook.getSheetAt(0);
//        XSSFDrawing patriarch = sheet.createDrawingPatriarch();
//
//        sheet.getRow(2).getCell(7).setCellValue(dto.getCode());
//        sheet.getRow(3).getCell(2).setCellValue(dto.getName());
//        sheet.getRow(3).getCell(6).setCellValue(dto.getCompanyname());
//        sheet.getRow(4).getCell(2).setCellValue(dto.getDivisionname());
//        sheet.getRow(4).getCell(6).setCellValue(dto.getApplusername()+"/"+dto.getApplposition());
//        sheet.getRow(5).getCell(2).setCellValue(dto.getImplementteam());
//
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日");
//        String valuestr = null;
//        String beforeDate = null;
//        String afterDate = null;
//        if (dto.getImprovebeforedate()!=null){
//            beforeDate = sdf.format(dto.getImprovebeforedate());
//        }
//        if (dto.getImproveafterdate()!=null){
//            afterDate = sdf.format(dto.getImproveafterdate());
//        }
//        if (beforeDate!=null && afterDate!=null) {
//            valuestr = beforeDate+"~"+afterDate;
//        }
//        sheet.getRow(5).getCell(6).setCellValue(valuestr);
//
//        Set<String> beforeImgs = getImgStr(dto.getImprovebefore());
//        int index1 = 0;
//        for (String filepath : beforeImgs) {
//            File file = new File("D:\\" + filepath);
//            if (file.exists()) {
//                setPhoto(workbook, patriarch, 8,0, file, index1);
//            }
//            index1++;
//        }
//        sheet.getRow(8).getCell(0).setCellValue(HtmlUtils.delHTMLTag(dto.getImprovebefore()));
//
//        Set<String> afterImgs = getImgStr(dto.getImproveafter());
//        int index2 = 0;
//        for (String filepath : afterImgs) {
//            File file = new File("D:\\" + filepath);
//            if (file.exists()) {
//                setPhoto(workbook, patriarch, 8,4, file, index2);
//            }
//            index2++;
//        }
//        sheet.getRow(8).getCell(4).setCellValue(HtmlUtils.delHTMLTag(dto.getImproveafter()));
//
//        sheet.getRow(10).getCell(2).setCellValue(dto.getApplicablescenario());
//        sheet.getRow(11).getCell(2).setCellValue(dto.getPromotionunit());
//        sheet.getRow(12).getCell(2).setCellValue(dto.getInstructions());
//        sheet.getRow(13).getCell(2).setCellValue(dto.getAdvanddisad());
//        sheet.getRow(14).getCell(2).setCellValue(dto.getInvestment());
//        sheet.getRow(15).getCell(2).setCellValue(dto.getEconbenefit());
//        sheet.getRow(16).getCell(2).setCellValue(dto.getMgtbenefit());
//
//        ByteArrayOutputStream bos = new ByteArrayOutputStream();
//        workbook.write(bos);
//        byte[] barray = bos.toByteArray();
//        String base64Excel = DatatypeConverter.printBase64Binary(barray);
//        bos.close();
//        workbook.close();
//
//        return base64Excel;
//    }

    public static void setPhoto(Workbook workbook, XSSFDrawing patriarch, int rowindex, int cellindex, File file, int index) {

        BufferedImage bufferImg = null;
        ByteArrayOutputStream byteArrayOut = new ByteArrayOutputStream();
        String formatName =file.getPath().substring(file.getPath().lastIndexOf(".")+1);

        try {
            bufferImg = ImageIO.read(file);
            ImageIO.write(bufferImg, formatName, byteArrayOut);
            XSSFClientAnchor anchor = new XSSFClientAnchor(0, 0, 0, 0, cellindex, rowindex, (cellindex+index), rowindex);
            anchor.setAnchorType(ClientAnchor.AnchorType.MOVE_AND_RESIZE);
            patriarch.createPicture(anchor,
                    workbook.addPicture(byteArrayOut.toByteArray(), Workbook.PICTURE_TYPE_JPEG)).resize(1,0.25);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Set<String> getImgStr(String htmlStr) {
        Set<String> pics = new HashSet<>();
        String img = "";
        Pattern p_image;
        Matcher m_image;
        String regEx_img = "<img.*src\\s*=\\s*(.*?)[^>]*?>";
        p_image = Pattern.compile(regEx_img, Pattern.CASE_INSENSITIVE);
        m_image = p_image.matcher(htmlStr);
        while (m_image.find()) {
            img = m_image.group();
            Matcher m = Pattern.compile("src\\s*=\\s*\"?(.*?)(\"|>|\\s+)").matcher(img);
            while (m.find()) {
                pics.add(m.group(1));
            }
        }
        return pics;
    }

}
