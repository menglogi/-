package com.example.mydemo1.util;

import com.example.mydemo1.dao.CheckAcceptDao;
import com.example.mydemo1.dao.PlantablesDao;
import com.example.mydemo1.entity.CheckAndAccept;
import com.example.mydemo1.entity.Plantables;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.sl.usermodel.PictureData;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * 工具来源：https://blog.csdn.net/hgg923/article/details/89924022
 * Excel 调整大小后图片不清晰：  文件-选项-高级-图像大小和质量
 */
@Component
public class POIExcelUtil {
    @Autowired
    CheckAcceptDao checkAcceptDao;
    @Autowired
    private PlantablesDao plantablesDao;

    //@Autowired
    static CheckAndAccept checkAndAccept =new CheckAndAccept() ;
    //获取文件名中的BKM-C编号
    static String imgname;
    //复制前数据
    static StringBuilder startImg ;
    //复制后的数据
    static StringBuilder endImg;
    //时间格式
    DateFormat dateformat= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    //读取excel文件 仅限xlxs
    public  void getDataFromExcel(String filePath) throws IOException {
        startImg =new StringBuilder();
        endImg=new StringBuilder();
        //未完成
        if (filePath.endsWith(".xls")) {
//            filePath=filePath.
        }else if (filePath.endsWith(".xlsx")){
            imgname=filePath.substring(filePath.indexOf("2021"),filePath.indexOf(".xlsx"));
        }
        //判断是否为excel类型文件
        if (!filePath.endsWith(".xls") && !filePath.endsWith(".xlsx")) {
            System.out.println("文件不是excel类型");
        }
        //创建文件数据
        FileInputStream fis = null;
        Workbook wookbook = null;
        Sheet sheet = null;
        try {
            //获取一个绝对地址的流
            fis = new FileInputStream(filePath);
            /* 读取网络文件（比如七牛等云存储）
            URL url = new URL(filePath);
            BufferedInputStream fis = new BufferedInputStream(url.openStream());*/
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            //2003版本的excel，用.xls结尾
            wookbook = new HSSFWorkbook(fis);//得到工作簿
        } catch (Exception ex) {
            try {
                //2007版本的excel，用.xlsx结尾
                fis = new FileInputStream(filePath);
                wookbook = new XSSFWorkbook(fis);//得到工作簿
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        Map<String, XSSFPictureData> maplist=null;
        sheet = wookbook.getSheetAt(0);
        try {
            // 判断用07还是03的方法获取图片
            if (filePath.endsWith(".xls")) {
//            maplist = getPictures1((HSSFSheet) sheet);
            } else if (filePath.endsWith(".xlsx")) {
                maplist = getPictures2((XSSFSheet) sheet);
            }
            Map<String, String> picPathList = null;
            picPathList = printImg(maplist);
            for (Map.Entry<String, XSSFPictureData> entry : maplist.entrySet()) {
                System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("文档无图片——————————————————————————————————————————————");
        } finally {
            //释放map
            if (maplist != null) {
                maplist = null;
            }
        }
        //得到一个工作表
        //获得表头
        Row rowHead = sheet.getRow(0);

        //获得数据的总行数
        int totalRowNum = sheet.getLastRowNum();
        Cell cell;
        try{
            //获得所有数据
            for (int i = 1; i <= totalRowNum; i++) {
                //获得第i行对象
                Row row = sheet.getRow(i);
                //遍历当前行中的数据
                for (int j=0;j<row.getLastCellNum();j++){
                    //物品编号位置(为空则跳过解析)
                    cell= row.getCell(j);
                    if (cell!=null&&cell.toString()!=""){
                        //给实体类赋值
                        if(cell.toString().equals("BKM编号")){
                            checkAndAccept.setPlanid(filePath.substring(filePath.indexOf("2021"),filePath.indexOf(".xlsx")).replaceAll("[^a-zA-Z0-9]","").trim());
                        }
                        if(cell.toString().equals("BKM复制内容")){
                            checkAndAccept.setCopycontent(row.getCell(j+1).toString().trim());
                        }
                        if(cell.toString().equals("BKM复制效果")){
                            checkAndAccept.setCopyeffect(row.getCell(j+1).toString().trim());
                        }
                        if(cell.toString().equals("公司推进办申请")){
                            checkAndAccept.setStatus(row.getCell(j+1).toString().trim().trim());
                        }
                        if(cell.toString().equals("先进制造推进部\n审核意见")){
                            checkAndAccept.setRemark(row.getCell(j+1).toString().trim());
                        }
                        if (cell.toString().equals("复制前后对比（形式不限）")){
                            startImg.append(sheet.getRow(i+1).getCell(0).toString().length()>0 ? sheet.getRow(i+1).getCell(0).toString().trim()+";":sheet.getRow(i+1).getCell(0).toString());
                            endImg.append(sheet.getRow(i+1).getCell(2).toString().length()>0 ? sheet.getRow(i+1).getCell(2).toString().trim()+";":sheet.getRow(i+1).getCell(2).toString());
                        }
                    }
                    if (cell == null) {
                        continue;
                    }
                }

            }
            //赋值  复制前后对比的信息(图片保存路劲+文字  用;隔开)
            checkAndAccept.setCopybefore(startImg.toString());
            checkAndAccept.setCopyafter(endImg.toString());
        }catch (Exception e){
            System.out.println("数据不符合规范");
        }

        //使用完成关闭
        wookbook.close();
        if (fis != null) {
            fis.close();
        }
        //给固定值赋值
        checkAndAccept.setCrdate(dateformat.format(new Date()));
        checkAndAccept.setModate(dateformat.format(new Date()));
        checkAndAccept.setDeleteor(null);
        checkAndAccept.setCruser("陈伟滨");
        checkAndAccept.setMouser("陈伟滨");
        //存储到数据库
        checkAcceptDao.save(checkAndAccept);
    }

    /**
     * 获取图片和位置 (xls)
     *未进行实际操作
     * @param sheet
     * @return
     * @throws IOException
     */
    public static Map<String, PictureData> getPictures1(HSSFSheet sheet) throws IOException {
        Map<String, PictureData> map = new HashMap<String, PictureData>();
        List<HSSFShape> list = sheet.getDrawingPatriarch().getChildren();
        for (HSSFShape shape : list) {
            if (shape instanceof HSSFPicture) {
                HSSFPicture picture = (HSSFPicture) shape;
                HSSFClientAnchor cAnchor = (HSSFClientAnchor) picture.getAnchor();
                PictureData pdata = (PictureData) picture.getPictureData();
                String key = cAnchor.getRow1() + "-" + cAnchor.getCol1(); // 行号-列号
                String proName = sheet.getRow(cAnchor.getRow1()).getCell(0).getStringCellValue();
                if(cAnchor.getCol1()==1){
                    key = proName+="01";
                }else if(cAnchor.getCol1()==11){
                    key = proName+="02";
                }
                map.put(key, pdata);
            }
        }
        return map;
    }

    /**
     * 获取图片和位置 (xlsx)
     *
     * @param sheet
     * @return
     * @throws IOException
     */
    public static Map<String, XSSFPictureData> getPictures2(XSSFSheet sheet) throws IOException {
        int js=0;
        Map<String, XSSFPictureData> map = new HashMap<String, XSSFPictureData>();
        List<XSSFShape> list = sheet.getDrawingPatriarch().getShapes();
        for (XSSFShape shape : list) {
            if (shape instanceof XSSFPicture) {
                XSSFPicture picture = (XSSFPicture) shape;
                XSSFClientAnchor cAnchor = (XSSFClientAnchor) picture.getAnchor();
                XSSFPictureData pdata = picture.getPictureData();
                String key = cAnchor.getRow1() + "-" + cAnchor.getCol1()+"-"+js; // 行号-列号
//                System.out.println(key);
                map.put(key, pdata);
                js++;
            }
        }
        return map;
    }


    /**
     * 图片写出
     * 保存到本地中 imgSaveDir+jpgFileName 为存储路劲和文件名
     */
    public static Map<String,String> printImg(Map<String, XSSFPictureData> maplist) throws IOException {

        Object[] mapkey=maplist.keySet().toArray();
        Object key[] = maplist.keySet().toArray();
        String imgSaveDir = "F:\\YaSuo";
        File file = new File(imgSaveDir);
        if(!file.exists()) { //目录不存在则创建
            file.mkdirs();
        }
        Map<String,String> temMap = new HashMap<>();
            for (int i = 0; i < maplist.size(); i++) {
            // 获取图片流
            XSSFPictureData pic = maplist.get(key[i]);
            // 获取图片索引
            //String picName = key[i].toString();
            String jpgFileName = "/img_"+imgname+"_"+mapkey[i]+".jpg";
            temMap.put(key[i].toString(),jpgFileName);
            byte[] data = pic.getData();
            //图片保存路径
            FileOutputStream out = new FileOutputStream(imgSaveDir+jpgFileName);
            String weizi=mapkey[i].toString().substring(mapkey[i].toString().indexOf("-")+1,mapkey[i].toString().indexOf("-")+2);
            if (Integer.parseInt(weizi)<2){
                startImg.append(imgSaveDir+jpgFileName+";");
            }else if (Integer.parseInt(weizi)>=2){
                endImg.append(imgSaveDir+jpgFileName+";");
            }

            //数据存储图片
            out.write(data);
            out.close();
        }
        checkAndAccept.setCopybefore(startImg.toString());
        checkAndAccept.setCopyafter(endImg.toString());
        return temMap;
    }

    /**
     * C计划表的导入执行过程
     * @param pathFeil 文件的路径+文件名
     * @throws Exception
     */
    public void getDataFromExcelCschedule(String pathFeil) throws Exception{
        //获取文件流
        FileInputStream inputStream=new FileInputStream(pathFeil);
        //创建一个工作簿。使用exceL能操作的这边他都可以操作!
        Workbook workbook = new XSSFWorkbook(inputStream);
        Sheet sheet = workbook.getSheetAt(0);

        //获取标题内容【表中的第一行】
        Row rowTitle = sheet.getRow(0);
        if ( rowTitle!=null) {
            //一定要掌握  getPhysicalNumberOfcells读取当前有数据的列数
            int cellcount = rowTitle.getPhysicalNumberOfCells();
            for (int cellNum = 0; cellNum < cellcount; cellNum++) {
                Cell cell = rowTitle.getCell(cellNum) ;
                if ( cell !=null){
                    CellType ce1lType = cell.getCellTypeEnum();
                    String cel1Value = cell.getStringCellValue();
                    //显示标题【名称|性别|名字|id|...】
//                    System.out.print(cel1Value + " | ");
                }
            }
        }
        //存储列中的数据
        List listEntity=new ArrayList();
        //指定表中的数据从哪一行开始获取
        int rowCount = sheet.getPhysicalNumberOfRows();
        //行数已经获取了，所有从数据开始遍历
        for (int rowNum = 3; rowNum < rowCount ; rowNum++) {
            Row rowData=sheet.getRow(rowNum);
            if(rowData!=null){
                //读取列数 getPhysicalNumberOfcells
                int cellCount = rowTitle.getPhysicalNumberOfCells();
                //遍历行中的数据每一列数据
                for (int cellNum = 0; cellNum < cellCount ; cellNum++) {
                    //当前列的数据
                    Cell cell = rowData.getCell( cellNum) ;
                    if(cell!=null){
                        //获取当前数据的类型
                        CellType ce11Type = cell.getCellTypeEnum( );
                        //获取当前数据
                        String cellValue ="";
                        //根据需要的列数或者指定数据
                        if (cellNum==0||cellNum==3||cellNum==5||cellNum==6||cellNum==7||cellNum==8||cellNum==9||cellNum==10||cellNum==11||cellNum==12||cellNum==13){
                            //根据列中数据类型进行专门的数据接收
                            switch (ce11Type) {
                                case STRING:
                                    cellValue = cell.getStringCellValue();
                                    break;
                                case FORMULA:
                                    int hs=rowNum-2;
//                                    System.out.println("当前序号 "+rowNum);
                                    cellValue = String.valueOf(hs);
                                    break;
                                case BLANK:
                                    cellValue = cell.getStringCellValue();
                                    break;
                                case NUMERIC:
                                    if (HSSFDateUtil.isCellDateFormatted(cell)) { //日期
                                        //日期
                                        Date date = cell.getDateCellValue();
                                        cellValue = dateformat.format(date);
                                    } else {
                                        //不是日期格式，防止数字过长 cel1.setce11Type(HSSFCe11.CELL_TYPE_STRING)
                                        cell.setCellType(HSSFCell.CELL_TYPE_STRING);
                                        cellValue = cell.toString();
                                        break;
                                    }
                            }
                            listEntity.add(cellValue);
                        }else {
                            //不属于指定列的跳过
                            continue;
                        }
                    }
                }
            }
            //对实体类赋值并存储数据
            if (listEntity!=null&&listEntity.size()==11){
                //给实体类赋值
                Plantables plantables =new Plantables();
                plantables.setId(listEntity.get(0).toString());
                plantables.setBkmid(listEntity.get(1).toString());
                plantables.setDirector(listEntity.get(4).toString());
                plantables.setApplcompanyid(listEntity.get(2).toString());
                plantables.setAppldivisionid(listEntity.get(3).toString());
                plantables.setProgramme(listEntity.get(5).toString());
                plantables.setBegindate(listEntity.get(6).toString());
                plantables.setEnddate(listEntity.get(7).toString());
                plantables.setProcess(listEntity.get(8).toString());
                plantables.setStatus(listEntity.get(9).toString());
                plantables.setRemark(listEntity.get(10).toString());
                plantables.setCrdate(dateformat.format(new Date()));
                plantables.setModate(dateformat.format(new Date()));
                //存储到数据库
                plantablesDao.save(plantables);
                //清空list集合方便下次循环使用
                listEntity.clear();
            }
        }
        //关闭文件流
        inputStream.close();
    }

}
