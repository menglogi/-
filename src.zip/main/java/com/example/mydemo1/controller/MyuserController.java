package com.example.mydemo1.controller;

import com.example.mydemo1.entity.Myuser;
import com.example.mydemo1.service.MyUserService;

import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

//数据交互测试
@RestController
@RequestMapping("/myuser")
public class MyuserController {
    @Resource
    private MyUserService mus;

    //获取单条记录
/*   @GetMapping */
    @GetMapping("/{id}")
    public Myuser getId(@PathVariable int id){
        return mus.get(id);
    }

    //查询全部
    @GetMapping()
    public List<Myuser> getAll(){
        List<Myuser> list=mus.getAll();
        System.out.println(list);
        return list;
    }
    //修改数据
    @PutMapping
    public int update(@RequestBody Myuser myuser){
        return mus.update(myuser);
    }
    //新增数据
    @PostMapping
    public int save(@RequestBody Myuser myuser){
        return mus.save(myuser);
    }
    @DeleteMapping("{id}")
    public int delete(@PathVariable int id){
        return mus.deletes(id);
    }

}

