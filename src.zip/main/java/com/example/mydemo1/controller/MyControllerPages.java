package com.example.mydemo1.controller;

import org.springframework.stereotype.Controller;

//页面跳转的测试
@Controller
class MyControllerPages{
//    @RequestMapping(value = "/index", method = RequestMethod.GET)
//    public String index() {
//        return "/test.html";
//    }


}
