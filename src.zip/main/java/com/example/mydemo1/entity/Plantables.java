package com.example.mydemo1.entity;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import lombok.Data;
/**
 * POI
 */
@Data
public class Plantables {

    private String  id;
    private String  bkmid;              //BKM编号
    private String  director;           //责任人
    private String  applcompanyid;      //BKM-C编号
    private String  appldivisionid;     //BKM-C公司
    private String  programme;          //复制方案
    private String  begindate;        //复制推广-开始时间
    private String  enddate;          //复制推广-结束时间
    private String  process;            //进度监控
    private String  status;             //验收是否通过
    private String  remark;        //备注
    private String  deleteor;           //默认0
    private String  cruser="陈伟滨";     //创建用户
    private String  crdate;             //创建日期
    private String  mouser="陈伟滨";     //修改人\
    private String  modate;             //修改时间
}
