package com.example.mydemo1.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.awt.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Myuser {
    private Integer user_id;
    private String user_software;
    private String user_account;
    private String user_password;
    private String user_create_user;
    private String user_software_route;
}
