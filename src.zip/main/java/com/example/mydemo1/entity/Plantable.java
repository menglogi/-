package com.example.mydemo1.entity;

import com.alibaba.excel.annotation.ExcelIgnore;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.annotation.format.DateTimeFormat;
import lombok.Data;

import java.util.Date;

/**
 * 阿里巴巴工具需要的实体类
 */
@Data
public class Plantable {
    @ExcelProperty(value = "ID",index =0 )
    private String  id;
    @ExcelProperty(value = "BKM编号",index =3 )
    private String  bkmid;              //BKM编号
    @ExcelProperty(value = "责任人",index =7 )
    private String  director;           //责任人
    @ExcelProperty(value = "BKM-C编号",index =5 )
    private String  applcompanyid;      //BKM-C编号
    @ExcelProperty(value = "BKM-C公司",index =6 )
    private String  appldivisionid;     //BKM-C公司
    @ExcelProperty(value = "复制方案",index =8 )
    private String  programme;          //复制方案
    @ExcelProperty(value = "开始时间",index =9 )
    @DateTimeFormat("yyyy-MM-dd")
    private String    begindate;        //复制推广-开始时间
    @ExcelProperty(value = "完成时间",index =10 )
    @DateTimeFormat("yyyy-MM-dd")
    private String    enddate;          //复制推广-结束时间
    @ExcelProperty(value = "进度监控",index =11 )
    private String  process;            //进度监控
    @ExcelProperty(value = "验收是否通过",index =12 )
    private String  status;             //验收是否通过
    @ExcelProperty(value = "备注",index =13 )
    private String  remark = "";        //备注
    @ExcelIgnore
    private String  deleteor;           //默认0
    @ExcelIgnore
    private String  cruser="陈伟滨";     //创建用户
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    private String  crdate;             //创建日期
    @ExcelIgnore
    private String  mouser="陈伟滨";     //修改人\
    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
    private String  modate;             //修改时间
}
