package com.example.mydemo1.entity;

import lombok.Data;

/**
 * POI
 */
@Data
public class CheckAndAccept {
    private String id;
    private String planid;          //BKM编号
    private String copybefore;      //复制起止图片
    private String copyafter;       //复制截止图片
    private String copycontent;     //BKM复制内容
    private String copyeffect;      //BKM复制效果
    private String status;          //公司推进办申请
    private String remark;          //先进制造推进部审核意见
    private String deleteor;        //默认0
    private String cruser;          //创建用户
    private String crdate;          //创建日期
    private String mouser;          //修改人
    private String modate;          //修改时间
}
