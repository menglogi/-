package com.example.mydemo1.dao;

import com.example.mydemo1.entity.Myuser;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper()
public interface MyUsrDao {
    //查询全部
    @Select("select * from user_c_w_b ")
    public List<Myuser> getAll();
    //单个查询
    @Select("select * from user_c_w_b where user_id=#{user_id}")
    public  Myuser getId(int user_id);

    @Select("<script> select * from user_c_w_b where 1=1 " +
            "<if test='user_id != null'> and  user_id = #{user_id}</if>" +
            "<if test='user_software != null'> and  user_software = #{user_software}</if>" +
            "LIMIT #{pageNum} ,#{pageSize} </script> ")
    public List<Myuser> getConditionAll(@Param(value = "user_id") int user_id,
                                        @Param(value = "user_software") String user_software,
                                        @Param(value = "user_software") String pageNum,
                                        @Param(value = "user_software") String pageSize);

    @Update("UPDATE user_c_w_b a SET a.user_software =#{user_software},a.user_account =#{user_account}, a.user_password=#{user_password},a.user_create_user=#{user_create_user}, a.user_software_route=#{user_software_route} where user_id=#{user_id}")
    public  int update(Myuser myuser);
    @Delete("delete from user_c_w_b where user_id=#{user_id} and user_software=#{user_software} ")
    public  int deletes(@Param(value = "user_id") int id,@Param(value = "user_software") String user_software);

    @Delete("delete from user_c_w_b where user_id=#{user_id} ")
    public  int delete(@Param(value = "user_id") int id);

    @Insert("INSERT INTO user_c_w_b " +
            "(user_software,user_account,user_password,user_create_user,user_software_route) " +
            "values (#{user_software},#{user_account},#{user_password},#{user_create_user},#{user_software_route}) ")
    @Options(useGeneratedKeys=true, keyProperty="user_id", keyColumn="user_id")
    public  int save(Myuser myuser);
}
