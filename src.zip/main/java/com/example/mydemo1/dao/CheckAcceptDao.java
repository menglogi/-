package com.example.mydemo1.dao;

import com.example.mydemo1.entity.CheckAndAccept;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper()
public interface CheckAcceptDao {

    @Insert("INSERT INTO bkmc_checkandaccept " +
            "(planid, copybefore, copyafter, copycontent, copyeffect, status," +
            "remark,deleteor, cruser, crdate, mouser, modate) " +
            "values (#{planid},#{copybefore},#{copyafter},#{copycontent},#{copyeffect},#{status}," +
            "#{remark},#{deleteor},#{cruser},#{crdate},#{mouser},#{modate})")
    public  int save(CheckAndAccept CheckAndAccept);

    @Select("select * from bkmc_checkandaccept  where planid=#{planid}")
    public CheckAndAccept getId(String planid);

}
