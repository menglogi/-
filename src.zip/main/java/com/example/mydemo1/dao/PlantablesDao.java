package com.example.mydemo1.dao;


import com.example.mydemo1.entity.Plantables;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface PlantablesDao {

    @Insert("INSERT INTO bkmc_plantable " +
            "(id, bkmid, director, applcompanyid, appldivisionid, programme, begindate, enddate, process, status," +
            " remark, deleteor, cruser, crdate, mouser, modate) " +
            "values (#{id},#{bkmid},#{director},#{applcompanyid},#{appldivisionid},#{programme},#{begindate},#{enddate},#{process}" +
            ",#{status},#{remark},#{deleteor},#{cruser},#{crdate},#{mouser},#{modate})")
    public  int save(Plantables plantables);
}
