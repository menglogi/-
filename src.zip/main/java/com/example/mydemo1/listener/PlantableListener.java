package com.example.mydemo1.listener;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.example.mydemo1.dao.PlantableDao;
import com.example.mydemo1.entity.Plantable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class PlantableListener extends AnalysisEventListener<Plantable> {

    @Autowired
    private  PlantableDao plantableDao ;

    @Override
    public void invoke(Plantable plantable, AnalysisContext analysisContext) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        if (plantable.getId()!=null){
            if (!plantable.getId().equals("序号")) {
                plantable.setCrdate(sdf.format(new Date()));
                plantable.setModate(sdf.format(new Date()));
                plantable.setDeleteor(null);
                plantable.setCruser("陈伟滨");
                plantable.setMouser("陈伟滨");
                int i =plantableDao.save(plantable);
            }
        }
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {

    }
}
