package com.example.mydemo1;

import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.read.builder.ExcelReaderBuilder;
import com.alibaba.excel.read.builder.ExcelReaderSheetBuilder;
import com.example.mydemo1.dao.CheckAcceptDao;
import com.example.mydemo1.dao.PlantableDao;
import com.example.mydemo1.entity.Plantable;
import com.example.mydemo1.listener.PlantableListener;
import com.example.mydemo1.util.POIExcelUtil;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import javax.annotation.Resource;
import java.io.*;


@SpringBootTest
class Mydemo1ApplicationTests {
    @Resource
    PlantableDao plantableDao;
    @Autowired
    POIExcelUtil poiExcelUtil;

    @Autowired
    CheckAcceptDao checkAcceptDao;
    @Autowired
    PlantableListener plantableListener;
//    @Autowired
//    CheckAcceptListener checkAcceptListener;

    /**
     * 阿里巴巴工具测试
     */
    @Test
    void contextLoads()  {
        //获取一个工作簿
        ExcelReaderBuilder readWorkBook=  EasyExcel.read("E:\\洛阳金鹭\\洛阳金鹭BKM-C计划表.xlsx", Plantable.class,plantableListener);
        //获取工作簿中第一页的信息   headRowNumber可以指定从第几行开始读取
        ExcelReaderSheetBuilder sheet= readWorkBook.sheet().headRowNumber(3);
        //读取工作表中内容
        sheet.doRead();
    }


    /**
     * POI 工具测试
     * BKMC验收表
     */
    @Test
    void contextLoad2() throws IOException {
        //单个文件存储
//        poiExcelUtil.getDataFromExcel("E:\\洛阳金鹭\\5月份\\2021BKMCGL0012验收表.xlsx");
        //获取文件路径文件夹下的全部文件列表
        System.out.println("文件有如下：");
        //表示一个文件路径
        File file = new File("E:\\洛阳金鹭\\BKMC验收表");
        //用数组把文件夹下的文件存起来
        File[] files = file.listFiles();
        //foreach遍历数组
        for (File file2 : files) {
            //打印文件列表：只读取名称使用getName();
//            System.out.println("路径："+file2.getPath());
            poiExcelUtil.getDataFromExcel(file2.getPath().toString());
//            System.out.println("文件夹/文件名："+file2.getName());
        }
    }

    /**
     * POI 工具测试
     *洛阳金鹭BKM-C计划表.xlsx(这张表存在一定问题需注意)
     */
    @Test
    void contextLoad3() throws Exception {
        //文件excle的文件位置及文件名
        String path="E:\\洛阳金鹭\\洛阳金鹭BKM-C计划表.xlsx";
        poiExcelUtil.getDataFromExcelCschedule(path);
    }
    /**
     * 数据库导入图片
     */
    @Test
    void contextLoad4() throws Exception {


    }
}
