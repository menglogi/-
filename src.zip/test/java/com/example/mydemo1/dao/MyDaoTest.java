package com.example.mydemo1.dao;

import com.example.mydemo1.entity.Myuser;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
public class MyDaoTest {
    @Autowired
    private MyUsrDao myUsrDao;

    @Test
    public void getAll() {
        List<Myuser> list = myUsrDao.getAll();
        for (int i=0;list.size()>i;i++){
            System.out.println(list.get(i));
        }

    }

//    @Test
//    public void getId() {
//        List<Myuser> list = myUsrDao.getId(1);
//        System.out.println(list);
//    }

}