package com.example.mydemo1.dao;

import com.example.mydemo1.entity.Myuser;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

@SpringBootTest
public class MyUsrDaoTest {
    @Autowired
    private MyUsrDao myUsrDao;

    @Resource
    PlantableDao plantableDao;
    @Test
    public void getId() {
        Myuser myuser= myUsrDao.getId(1);
        System.out.println(myuser);
    }

    @Test
    public void update() {
        Myuser myuser=new Myuser(6,"432","432","432","432","432");
        int t= myUsrDao.update(myuser);
        System.out.println("update成功-------"+t);
    }

    @Test
    public void delete() {
        int i=myUsrDao.delete(8);
        System.out.println("dete删除------"+i);
    }

    @Test
    public void deletes() {
        int i=myUsrDao.deletes(8,"212");
        System.out.println("dete删除------"+i);
    }


    @Test
    public void getConditionAll() {
        //
    }

    @Test
    public void testUpdate() {
        Myuser myuser=new Myuser(9,"432","432","432","432","432");
        int i =myUsrDao.update(myuser);
        System.out.println("update ----- "+i);
    }

    @Test
    public void testDelete() {
        int i =myUsrDao.delete(9);
        System.out.println("delete ----- "+i);
    }

    @Test
    public void save() {
        Myuser myuser=new Myuser();
        myuser.setUser_software("1213");
        myuser.setUser_account("1213");
        myuser.setUser_password("1213");
        myuser.setUser_create_user("1213");
        myuser.setUser_software_route("1213");
        int i=myUsrDao.save(myuser);
        System.out.println("save ----- "+i);
    }
}
